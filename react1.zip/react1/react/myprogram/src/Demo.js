import React from 'react'

export default class Demo extends React.Component
{
    constructor(props)
    {
        super(props)
       
    }
    render()
    {
        return <div>
            <h2>Demo Component</h2>
            <b>{this.props.data}</b>
            <br/>
            <button onClick={()=>this.props.fun('anu')}>Change</button>
        </div>
    }
}