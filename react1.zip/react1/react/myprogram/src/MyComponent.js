import React from "react";
export class first extends React.Component{
    render(){
        return <div><h1>hii team</h1></div>
    }
}