package com.alchemy.patient.patientvisit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientvisitApplicationTests {

	@Test
	void contextLoads() {
	}

}
