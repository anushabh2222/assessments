import express from "express";
import { engine } from "express-handlebars";

const app = express();
const port = process.env.PORT || 8080;

let m = {
  name: "person",
  cat: "person",
  people: [
    {
      id: 1,
      img: "https://png.pngtree.com/png-vector/20190114/ourlarge/pngtree-vector-avatar-icon-png-image_313572.jpg", 
      firstname: "Amulya",
      lastname: "Kalyan",
      role: "Trainer",
      details: {
        person: "training",
      },
    },
    {
      id: 2,
      img: "https://png.pngtree.com/png-vector/20190114/ourlarge/pngtree-vector-avatar-icon-png-image_313572.jpg", 
      firstname: "Aishwarya",
      lastname: "nagraj",
      role: "Developer",
      details: {
        person: "developer",
      },
    },
    {
      id: 3,
      img: "https://png.pngtree.com/png-vector/20190114/ourlarge/pngtree-vector-avatar-icon-png-image_313572.jpg", 
      firstname: "indu",
      lastname: "nagaraj",
      role: "tester",
      details: {
        person: "tester",
      },
    },
  ],
};
app.engine("handlebars", engine());
app.set("view engine", "handlebars");
app.set("views", "./views");

app.get("/", (req, res) => {
  res.render("home", { data: m });
});

app.get("/about", (req, res) => {
  res.render("about");
});

app.get("/details/:id", (req, res) => {
    m.people.forEach(e => {
        if(e.id == req.params.id) {
            res.render("details", {data: e});
        }
    });
});
app.listen(port, () => console.log(`App Started! ${port}`));
