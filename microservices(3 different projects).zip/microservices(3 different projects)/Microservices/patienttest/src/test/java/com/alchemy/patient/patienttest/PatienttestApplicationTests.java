package com.alchemy.patient.patienttest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatienttestApplicationTests {

	@Test
	void contextLoads() {
	}

}
