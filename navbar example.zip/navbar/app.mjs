import express from "express";
import { engine } from "express-handlebars";

var app = express();

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views','./views');

app.get('/', function (req, res) {
    res.render('home');
});

app.listen(3000);
